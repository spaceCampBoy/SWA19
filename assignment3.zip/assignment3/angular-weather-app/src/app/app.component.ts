import { Component } from '@angular/core';
import { WeatherService } from './services/weather.service';
import { WeatherData } from './components/model/WeatherModel'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-weather-app';
  model = new WeatherData();
  constructor(private weatherService: WeatherService) {
    this.weatherService.fetchWeather("data").subscribe(data => {
      console.log(data)
      this.model.includingHistoric(data);
      console.log(this.model.getCityOptions())
    });
    this.weatherService.fetchWeather("forecast").subscribe(data => {
      this.model.includingForecast(data)
    });
  }

  change(type)
  {
    console.log(type)
  }
}
