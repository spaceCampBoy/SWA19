import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-query-panel',
  templateUrl: './query-panel.component.html',
  styleUrls: ['./query-panel.component.css']
})
export class QueryPanelComponent implements OnInit {
  type;
  city;
  from;
  to;
  constructor() { }

  ngOnInit() {
  }

}
