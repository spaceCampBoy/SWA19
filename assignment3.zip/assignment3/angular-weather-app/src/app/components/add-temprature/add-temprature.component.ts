import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-temprature',
  templateUrl: './add-temprature.component.html',
  styleUrls: ['./add-temprature.component.css']
})
export class AddTempratureComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
